

function unique(arr){
    let set=new Set(arr);
    return set
}



console.log(...unique([1, 1, 1, 4, 5, 6, 4, 5, 6, 7, 8, 9, 9]))